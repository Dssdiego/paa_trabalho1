
#include <janela.h>

int main(int, char **)
{
    Janela::inicializa(1280, 720, (char *) "Trabalho 1 - Projeto e Análise de Algoritmos");
}
